/**********************************************************************************
 *																				  *
 * Copyright notice: please read file license.txt in the application root folder.  *
 *                                              								      *
 **********************************************************************************/

package util;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.FileNotFoundException;
import java.net.URL;
import java.util.Collection;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.StringTokenizer;

import dnsFilter.DnsFilterMonoliticVersionActivator;
import frog.export.log.Levels;


public class Domains {


	private List<String> categories;
	/*
	 * The following constant is a relative path within the JAR of the application
	 */
	private final String basedir = "config/blacklists/"; 
	private final String MODULE_NAME = DnsFilterMonoliticVersionActivator.MODULE_NAME;

	public Domains()
	{
		Logger.log(Levels.PEX_INFO, MODULE_NAME, "Trying to load the black list from file: " + basedir + "CATEGORIES");

		try {
			/*
			 * The file we are going to open is into the JAR of the application. Since the jar is a bundle, it is a bit
			 * complicated to get the file, but the following code exactly do it :D			
			 */
			URL url = this.getClass().getClassLoader().getResource(basedir + "CATEGORIES");
			if(url == null)
			{
				Logger.log(Levels.PEX_ERROR, MODULE_NAME, "Probably the application was compiled in a wrong way, since the file '" + basedir + "CATEGORIES' does not exist!");
				return;
			}
			
			Logger.log(Levels.PEX_DEBUG, MODULE_NAME, "URL: " + url);
			BufferedReader in = new BufferedReader(new InputStreamReader(url.openConnection().getInputStream()));

			String s;
			categories = new LinkedList<String>();

			while( (s = in.readLine()) != null)
			{
				if(s.contains("-"))
				{
					StringTokenizer st = new StringTokenizer(s, "-");
					this.categories.add(st.nextToken().trim());
				}
			}
			Logger.log(Levels.PEX_DEBUG, MODULE_NAME, "domains: finished reading file");
			in.close();
		} catch(FileNotFoundException e) {
			Logger.log(Levels.PEX_ERROR, MODULE_NAME, "The file containing the categories (/config/blacklists/CATEGORIES) was not found:" + e.getMessage());
			Logger.log(Levels.PEX_ERROR, MODULE_NAME, e.getStackTrace().toString());
			return;
		} catch (IOException e) {
			Logger.log(Levels.PEX_ERROR, MODULE_NAME, "Error while reading the file containing the categories (/config/blacklists/CATEGORIES): " + e.getMessage());
			Logger.log(Levels.PEX_ERROR, MODULE_NAME, e.getStackTrace().toString());
			return;
		}
		Logger.log(Levels.PEX_DEBUG, MODULE_NAME, "domains: domains created");
	}

	public Collection<String> getCategories()
	{
		return this.categories;
	}

	public Collection<String> getDomains(String category) throws IOException 
	{
		Logger.log(Levels.PEX_DEBUG, MODULE_NAME, "Getting domains specified in file '" + basedir + category +"/domains'");
		
		try{
			/*
			 * The file we are going to open is into the JAR of the application. Since the jar is a bundle, it is a bit
			 * complicated to get the file, but the following code exactly do it :D			
			 */
			URL url = this.getClass().getClassLoader().getResource(basedir + category  + "/domains");
			if(url == null)
			{
				Logger.log(Levels.PEX_ERROR, MODULE_NAME, "Probably the application was compiled in a wrong way, since the file '" + basedir + category + "domains' does not exist!");
				return null;
			}
			
			Logger.log(Levels.PEX_DEBUG, MODULE_NAME, "URL: " + url);
			BufferedReader in = new BufferedReader(new InputStreamReader(url.openConnection().getInputStream()));
			HashSet<String> domains = new HashSet<String>();

			String domain;
			while(( domain = in.readLine()) != null)
			{
				domains.add(domain);
			}
			in.close();

			return domains;
		} catch(FileNotFoundException e) {
			Logger.log(Levels.PEX_ERROR, MODULE_NAME, "domains: " + e.getMessage());
		}catch (IOException e) {
			Logger.log(Levels.PEX_ERROR, MODULE_NAME, "domains: " + e.getMessage());
		}
		Logger.log(Levels.PEX_DEBUG, MODULE_NAME, "get domains: return null");
		return null;
	}

	public Collection<String> getDomains(List<String> categories) throws IOException
	{

		HashSet<String> domains = new HashSet<String>();
		for(String name : categories)
			domains.addAll(this.getDomains(name));

		return domains;
	}
}
