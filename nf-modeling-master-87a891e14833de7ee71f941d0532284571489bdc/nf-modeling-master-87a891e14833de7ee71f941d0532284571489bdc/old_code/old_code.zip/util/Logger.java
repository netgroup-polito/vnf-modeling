/**
 * ********************************************************************************
 *																				  *
 * Copyright notice: please read file license.txt in the application root
 * folder. * *
 *********************************************************************************
 */
package util;

import frog.export.log.Levels;

public class Logger
{	
	private static frog.export.log.Logger logger;

	public static void setLogger(frog.export.log.Logger logger)
	{
		if(Logger.logger == null)
			Logger.logger = logger;
	}
	
	private Logger()
	{
		
	}
	
	public static void log(Levels loggingLevel, String moduleName, String msg)
	{
		if(Logger.logger != null)
			logger.log(loggingLevel, moduleName, msg);
	}
	
	public static void logPacket(String moduleName, byte[] packet, int packetSize, String msg)
	{
		if(Logger.logger != null)
			logger.logPacket(moduleName, packet, packetSize, msg);
	}
}
