package applib;

public class UDP
{
	public static final int HEADER_OFFSET = Ethernet.ETH_HLEN+IPv4.IP_HLEN;
	public final static int UDP_HLEN = 8;
}
