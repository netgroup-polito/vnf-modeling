package applib;

import java.util.Arrays;


public class ARP
{
	private final static int ARP_LEN = 42;
	private final static int OP_CODE_POS = 6;
	private final static short ARP_REQ = 1;
	private final static short ARP_REP = 2;
	private final static int SENDER_MAC_POS = 8;
	private final static int SENDER_IP_POS = 14;
	private final static int TARGET_MAC_POS = 18;
	private final static int TARGET_IP_POS = 24;
	
	private static byte[] arpReq = new byte[]{
		(byte)0xff, (byte)0xff, (byte)0xff, (byte)0xff, (byte)0xff, (byte)0xff,
		0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
		0x08, 0x06,
		0x00, 0x01, 0x08, 0x00, 0x06, 0x04, 0x00, 0x01,
		0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
		0x00, 0x00, 0x00, 0x00,
		0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
		0x00, 0x00, 0x00, 0x00
	};
	
	/*
	 * This method is called by the main function of this application, to check if
	 * the received packet is an ARP request.
	 */
	public static boolean isARPRequest(byte[] packet)
	{
		short type = (short)(((packet[Ethernet.ETH_TYPE_POS] << 8) & 0xff00) | (packet[Ethernet.ETH_TYPE_POS+1] & 0xff));
		short op = (short)(((packet[Ethernet.ETH_HLEN+OP_CODE_POS] << 8) & 0xff00) | (packet[Ethernet.ETH_HLEN+OP_CODE_POS+1] & 0xff));
		return (type == Ethernet.TYPE_ARP && op == ARP_REQ);
	}
	
	/*
	 * This method is called by the main function of this application, to check if
	 * the received packet is an ARP reply.
	 */
	public static boolean isARPReply(byte[] packet)
	{
		short type = (short)(((packet[Ethernet.ETH_TYPE_POS] << 8) & 0xff00) | (packet[Ethernet.ETH_TYPE_POS+1] & 0xff));
		short op = (short)(((packet[Ethernet.ETH_HLEN+OP_CODE_POS] << 8) & 0xff00) | (packet[Ethernet.ETH_HLEN+OP_CODE_POS+1] & 0xff));
		return (type == Ethernet.TYPE_ARP && op == ARP_REP);
	}

	/*
	 * This method is called by the main function of this application, to change
	 * an ARP request packet to an ARP reply packet with the given target MAC.
	 * Currently it supports only Ethernet and IPv4.
	 */
	public static byte[] generateARPRequest(int srcIp, byte[] srcMac, int dstIp)
	{
		byte[] req = new byte[ARP_LEN];
		System.arraycopy(srcMac, 0, arpReq, 6, 6);
		System.arraycopy(srcMac, 0, arpReq, Ethernet.ETH_HLEN+SENDER_MAC_POS, 6);
		System.arraycopy(IPv4.toIpAddrBytes(srcIp), 0, arpReq, Ethernet.ETH_HLEN+SENDER_IP_POS, 4);
		System.arraycopy(IPv4.toIpAddrBytes(dstIp), 0, arpReq, Ethernet.ETH_HLEN+TARGET_IP_POS, 4);
		System.arraycopy(arpReq, 0, req, 0, ARP_LEN);
		return req;
	}

	/*
	 * This method is called by the main function of this application, to change
	 * an ARP request packet to an ARP reply packet with the given target MAC.
	 * Currently it supports only Ethernet and IPv4.
	 */
	public static byte[] generateARPReply(byte[] req, byte[] targetMac)
	{
		byte[] rep = Arrays.copyOf(req, ARP_LEN);
		byte[]srcMac = targetMac;
		byte[]dstMac = Arrays.copyOfRange(req, 6, 12); 
		byte[]srcIp = Arrays.copyOfRange(req, Ethernet.ETH_HLEN+TARGET_IP_POS, Ethernet.ETH_HLEN+TARGET_IP_POS+4);
		byte[]dstIp = Arrays.copyOfRange(req, Ethernet.ETH_HLEN+SENDER_IP_POS, Ethernet.ETH_HLEN+SENDER_IP_POS+4);
		rep[Ethernet.ETH_HLEN+OP_CODE_POS+1] = ARP_REP;
		System.arraycopy(dstMac, 0, rep, 0, 6);
		System.arraycopy(srcMac, 0, rep, 6, 6);
		System.arraycopy(srcMac, 0, rep, Ethernet.ETH_HLEN+SENDER_MAC_POS, 6);
		System.arraycopy(srcIp, 0, rep, Ethernet.ETH_HLEN+SENDER_IP_POS, 4);
		System.arraycopy(dstMac, 0, rep, Ethernet.ETH_HLEN+TARGET_MAC_POS, 6);
		System.arraycopy(dstIp, 0, rep, Ethernet.ETH_HLEN+TARGET_IP_POS, 4);
		return rep;
	}
	
	public static short getArpPacketSize()
	{
		return ARP_LEN;
	}
	
	public static byte[] getSenderIp(byte[] req)
	{
		return Arrays.copyOfRange(req, Ethernet.ETH_HLEN+SENDER_IP_POS, Ethernet.ETH_HLEN+SENDER_IP_POS+4);
	}
	
	public static int getSenderIpInt(byte[] req)
	{
		return IPv4.toIpAddr(new byte[]{req[Ethernet.ETH_HLEN+SENDER_IP_POS],
				req[Ethernet.ETH_HLEN+SENDER_IP_POS+1],
				req[Ethernet.ETH_HLEN+SENDER_IP_POS+2],
				req[Ethernet.ETH_HLEN+SENDER_IP_POS+3]
		});
	}
	
	public static byte[] getSenderMac(byte[] req)
	{
		return Arrays.copyOfRange(req, Ethernet.ETH_HLEN+SENDER_MAC_POS, Ethernet.ETH_HLEN+SENDER_MAC_POS+6);
	}
	
	public static byte[] getTargetIp(byte[] req)
	{
		return Arrays.copyOfRange(req, Ethernet.ETH_HLEN+TARGET_IP_POS, Ethernet.ETH_HLEN+TARGET_IP_POS+4);
	}
	
	public static int getTargetIpInt(byte[] req)
	{
		return IPv4.toIpAddr(new byte[]{req[Ethernet.ETH_HLEN+TARGET_IP_POS],
				req[Ethernet.ETH_HLEN+TARGET_IP_POS+1],
				req[Ethernet.ETH_HLEN+TARGET_IP_POS+2],
				req[Ethernet.ETH_HLEN+TARGET_IP_POS+3]
		});
	}
	
	public static byte[] getTargetMac(byte[] req)
	{
		return Arrays.copyOfRange(req, Ethernet.ETH_HLEN+TARGET_MAC_POS, Ethernet.ETH_HLEN+TARGET_MAC_POS+6);
	}
}
