package applib;

import java.text.SimpleDateFormat;
import java.util.Date;

public class Msg
{
	public static byte ERROR = 4;
	public static byte WARNING = 2;
	public static byte DEBUG = 1;
	private static boolean debug = false;
	private static SimpleDateFormat timeFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
	
	public static void enableDebug()
	{
		debug = true;
	}
	
	public static void disableDebug()
	{
		debug = false;
	}
	
	public static void show(byte flags)
	{
		if(((flags & DEBUG) == DEBUG) && debug)
			System.out.println(timeFormat.format(new Date()));
	}
	
	public static void show(byte flags, boolean x)
	{
		if(((flags & DEBUG) == DEBUG) && debug)
			System.out.println(timeFormat.format(new Date()) + " " + x);
	}
	
	public static void show(byte flags, byte x)
	{
		if(((flags & DEBUG) == DEBUG) && debug)
			System.out.println(timeFormat.format(new Date()) + " " + x);
	}
	
	public static void show(byte flags, byte[] x)
	{
		if(((flags & DEBUG) == DEBUG) && debug)
			System.out.println(timeFormat.format(new Date()) + " " + x);
	}
	
	public static void show(byte flags, double x)
	{
		if(((flags & DEBUG) == DEBUG) && debug)
			System.out.println(timeFormat.format(new Date()) + " " + x);
	}
	
	public static void show(byte flags, float x)
	{
		if(((flags & DEBUG) == DEBUG) && debug)
			System.out.println(timeFormat.format(new Date()) + " " + x);
	}
	
	public static void show(byte flags, int x)
	{
		if(((flags & DEBUG) == DEBUG) && debug)
			System.out.println(timeFormat.format(new Date()) + " " + x);
	}
	
	public static void show(byte flags, long x)
	{
		if(((flags & DEBUG) == DEBUG) && debug)
			System.out.println(timeFormat.format(new Date()) + " " + x);
	}
	
	public static void show(byte flags, Object x)
	{
		if(((flags & DEBUG) == DEBUG) && debug)
			System.out.println(timeFormat.format(new Date()) + " " + x);
	}
	
	public static void show(byte flags, String x)
	{
		if(((flags & DEBUG) == DEBUG) && debug)
			System.out.println(timeFormat.format(new Date()) + " " + x);
	}
	
	public static void show(byte flags, String format, Object...args)
	{
		if(((flags & DEBUG) == DEBUG) && debug)
			System.out.printf(timeFormat.format(new Date()) + " " + format, args);
	}

}
