package applib;

public class MacAddr
{
	public final static byte[] BCAST_MAC = {(byte)0xff, (byte)0xff, (byte)0xff, (byte)0xff, (byte)0xff, (byte)0xff};
	private final static byte[] NULL_MAC = {0, 0, 0, 0, 0, 0};

	public static boolean isBroadcast(byte[] mac)
    {
		for(int i=0; i<6; i++)
		{
			if(mac[i] != -1)
				return false;
		}
		return true;
        //return mac.equals(BCAST_MAC);
    }
	public static boolean isMulticast(byte[] mac)
	{
        if (isBroadcast(mac))
            return false;
        return (mac[0] & 0x01) != 0;
    }

	public static boolean isNull(byte[] mac)
    {        
        return mac.equals(NULL_MAC);
    }
	
    public static long toLong(byte[] mac)
    {
        long macLong = 0;
        for (int i = 0; i < 6; i++) {
            long t = (mac[i] & 0xffL) << ((5 - i) * 8);
            macLong |= t;
        }
        return macLong;
    }
    
    public static String toString(long mac)
    {
        String macStr = "";
        for(int i=40; i>0; i-=8)
        	macStr += String.format("%02X:", (byte)((mac >> i) & 0xff));
    	macStr += String.format("%02X", (byte)(mac & 0xff));
        return macStr;
    }
    
    public static String toString(byte[] mac)
    {
        return String.format("%02X:%02X:%02X:%02X:%02X:%02X",
        		mac[0], mac[1], mac[2], mac[3], mac[4], mac[5]);
    }

}
