package applib;

public class DHCP
{
	private final static int DHCP_MAGIC_COOKIE_OFFSET = 0xec;
	private final static int DHCP_MAGIC_COOKIE_LENGTH = 4;
	private final static byte[] DHCP_MAGIC_COOKIE = {0x63, (byte)0x82, 0x53, 0x63};
	
	public static boolean isDhcp(byte[] packet)
	{
		for(int i=0; i<DHCP_MAGIC_COOKIE_LENGTH; i++)
		{
			if(packet[Ethernet.ETH_HLEN+IPv4.IP_HLEN+UDP.UDP_HLEN+DHCP_MAGIC_COOKIE_OFFSET+i] != DHCP_MAGIC_COOKIE[i])
				return false;
		}
		return true;
	}

}
