package applib;

import java.util.ArrayList;
import java.util.List;

import annotations.FieldExtraction;
import annotations.Predicate;


public class DNS {

	public static final int HEADER_OFFSET = Ethernet.ETH_HLEN+IPv4.IP_HLEN+UDP.UDP_HLEN;
	public static final int ID_POS = 0;
	public static final int FLAG_POS = 2;
	public static final int NUM_QUERY_POS  = 4;
	public static final int NUM_ANSWER_POS = 6;
	public static final int NUM_RR_POS = 8;
	public static final int NUM_ALT_POS = 10;
	public static final int QUESTION_POS = 12;
    public static final short INET_CLASS = 1;
    public static final short TYPE_A = 1;
    public static final short TYPE_AAAA = 28;
	
    @Predicate("packet.protocol() == DNS_QUERY")
	public static boolean isDnsQuery(byte[] packet)
	{
		
		return (Ethernet.getEtherType(packet) == Ethernet.TYPE_IPv4) &&
				(IPv4.getProtocol(packet) == IPv4.PROTOCOL_UDP) &&
				((packet[HEADER_OFFSET+FLAG_POS] == 0x01) && (packet[HEADER_OFFSET+FLAG_POS+1] == 0x00));
	}
	
    @FieldExtraction("packet.url()")
	public static List<DnsQuestion> getQuestions(byte[] packet)
	{
		List<DnsQuestion> questions = new ArrayList<DnsQuestion>();
		int numQuery = ((packet[HEADER_OFFSET+NUM_QUERY_POS]<<8)+packet[HEADER_OFFSET+NUM_QUERY_POS+1]) & 0xffff;
		int curPos = HEADER_OFFSET+QUESTION_POS;
		int length;

        for (int i = 0; i < numQuery; i++)
        {
            StringBuilder domainName = new StringBuilder();

            while((length = packet[curPos++]) != 0)
            {
                for (int k = 0; k < length; k++)
                {
                    domainName.append((char)packet[curPos++]);
                }

                domainName.append('.');
            }

            short domainType = (short)(((packet[curPos]<<8)+packet[curPos+1]) & 0xffff);
            curPos += 2;
            short domainClass = (short)(((packet[curPos]<<8)+packet[curPos+1]) & 0xffff);
            curPos += 2;

            questions.add(new DnsQuestion(domainName.toString(), domainType, domainClass));
        }
        return questions;
    }

}
