package applib;

import java.util.StringTokenizer;



public class DnsQuestion
{
    private String domainName;
    private short  domainType;
    private short  domainClass;
    
    public DnsQuestion(String domainName, short domainType, short domainClass)
    {
        this.domainName = domainName;
        this.domainType = domainType;
        this.domainClass = domainClass;
    }

    public String getDomainName()
    {
        return this.domainName;
    }

    public short getDomainType()
    {
        return this.domainType;
    }
    
    public short getDomainClass()
    {
        return this.domainClass;
    }
    
    public String getDomain()
    {
        
        StringTokenizer strtok = new StringTokenizer(this.domainName, ".",false);
         
        StringBuilder str = new StringBuilder();
       
        //strtok.nextToken(); // salto il primo token
        //FIXME: i don't know why the first part is deleted, i delete only "www"
        String firstToken = strtok.nextToken();
        if(!firstToken.equals("www"))
            str.append(firstToken+"."); 
        while (strtok.hasMoreTokens())
        {
            str.append(strtok.nextToken()+"."); 
        }
        
        return str.substring(0, str.length()-1).toString();
    }
}
