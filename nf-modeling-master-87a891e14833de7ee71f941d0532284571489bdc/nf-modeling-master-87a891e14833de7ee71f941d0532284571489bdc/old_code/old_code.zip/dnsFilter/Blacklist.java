/**********************************************************************************
*																				  *
* Copyright notice: please read file license.txt in the application root folder.  *
*                                              								      *
**********************************************************************************/

package dnsFilter;

import java.io.IOException;
import java.util.Collections;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

import util.Domains;
import util.Logger;
import dnsFilter.DnsFilterMonoliticVersionActivator;
import frog.export.log.Levels;


public class Blacklist {


	private static Blacklist instance = null;
	
	private  Set<String> blacklist = Collections.newSetFromMap(new ConcurrentHashMap<String, Boolean>());
	private  ConcurrentHashMap<String, Boolean> categories = new ConcurrentHashMap<String, Boolean>();
	private  Domains domains;   
	private static final String MODULE_NAME = DnsFilterMonoliticVersionActivator.MODULE_NAME;

	public static Blacklist getInstance()
	{
		if(instance == null)
		{
			instance = new Blacklist();
		}
		return instance;
		
	}

	public  boolean inizialize()
	{
		domains =  new Domains();
		if(domains.getCategories() == null)
			/*
			 * Something went wrong in the creation of the Domain object
			 */
			return false;
		
		Logger.log(Levels.PEX_DEBUG, MODULE_NAME, "black list: domains is created");
		for(String k : domains.getCategories())
			categories.put(k, false);
		Logger.log(Levels.PEX_DEBUG, MODULE_NAME, "black list: finished adding categories");
		return true;
	}

	public  void enable_categorie(String name) 
	{
		Logger.log(Levels.PEX_DEBUG, MODULE_NAME, "black list: enable category " + name);
		if(categories.containsKey(name))
		{
			Logger.log(Levels.PEX_DEBUG, MODULE_NAME, "black list: " + name + "is in categories");
			categories.put(name, true);
			try {
				Logger.log(Levels.PEX_DEBUG, MODULE_NAME, "black list: adding domains");
				blacklist.addAll(domains.getDomains(name));
				Logger.log(Levels.PEX_DEBUG, MODULE_NAME, "Category added - " + name);
				Logger.log(Levels.PEX_DEBUG, MODULE_NAME, "Total filtered domain: " +  blacklist.size());
			} catch (IOException e) {
				System.err.println(e);
			}
		}
	}

	public  void disable_categorie(String name)  
	{
		if(categories.containsKey(name))
		{
			categories.put(name, false);
			try {
				blacklist.removeAll(domains.getDomains(name));
			} catch (IOException e) {
				System.err.println(e);
			}
		}
	}


	public  Set<String> getBlacklist()
	{
		return blacklist;
	}

	public  Map<String, Boolean> getCategories() {
		return categories;
	}

	public  List<String> getEnabledCategories() {
		LinkedList<String> l  = new LinkedList<String>();

		for(String a : categories.keySet())
		{
			if(categories.get(a)){
				l.add(a);
			}

		}
		return l;
	}

	public static void calcel() {
		Logger.log(Levels.PEX_INFO, MODULE_NAME, "Remove the BlackListInstance");
		instance.blacklist.clear();
		instance.categories.clear();
		instance = null;
	}

}
