/**********************************************************************************
*																				  *
* Copyright notice: please read file license.txt in the application root folder.  *
*                                              								      *
**********************************************************************************/

package dnsFilter;

import java.util.LinkedHashMap;
import java.util.Map.Entry;

public class Cache<K, V> extends LinkedHashMap<K, V> {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	/**
	 * 
	 */
	private int maxSize = 1;

	public Cache(int maxSize) {
	this.maxSize = maxSize;
	}

	
	@Override
	protected boolean removeEldestEntry(Entry<K, V> eldest) {
		 return size() > this.maxSize;
	
	}


	


}

