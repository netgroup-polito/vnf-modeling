/************************************************************************************
*																					*
*     Copyright notice: please read file license.txt in the project root folder.    *
*                                              								        *
************************************************************************************/

/**
 * \file DnsFilterMoniliticVersion.java
 *
 * \author Luca Capano
 * \author Marco Pramotton
 * \author Ivano Cerrato
 *
 */

package dnsFilter;

//import java.util.logging.Logger;

import util.Logger;
import applib.DNS;
import dnsFilter.Blacklist;
import dnsFilter.DNS_Request_Blacklist_Handler;
import frog.export.log.Levels;
import frog.export.packetDispatcher.*;

public class DnsFilterMonoliticVersion implements PEXApplication{
	
	protected PacketDispatcher packetDispatcher;
	private ApplicationID id;	
	private  DNS_Request_Blacklist_Handler dns_handler;
	private Privileges privileges;
	private final String MODULE_NAME = DnsFilterMonoliticVersionActivator.MODULE_NAME;


	/*
	 * This method is called by the OSGi framework when the application 
	 * must be started.
	 */
	public boolean startUp()
	{
		Logger.log(Levels.PEX_INFO, MODULE_NAME, "DnsFillterMonoliticVersion is starting up...");
		
		id = packetDispatcher.GetID(this);
		privileges = packetDispatcher.getPrivileges();
		
		if(!privileges.canDropPacket())
			Logger.log(Levels.PEX_WARNING, MODULE_NAME, "I don't have the privilege to drop packets! My work will not have any effect!");				
						
		packetDispatcher.RegisterApplication(id);

		Logger.log(Levels.PEX_INFO, MODULE_NAME, "Child Control Started");

		Blacklist bl = Blacklist.getInstance();
		if(bl == null)
		{
			/*
			 * If the code enters here, probably there is a  bug somewhere
			 */
			Logger.log(Levels.PEX_ERROR, MODULE_NAME, "dns filter: failed getting instance of blacklist");
			return false;
		}
		if(!bl.inizialize())
		{
			Logger.log(Levels.PEX_ERROR, MODULE_NAME, "Unable to initialize the black list!");
			return false;
		}
		
		Logger.log(Levels.PEX_DEBUG, MODULE_NAME, "dns filter: blacklist initialized");
		
		/*
		*	We just enable two categories by default in the black list
		*/
		Blacklist.getInstance().enable_categorie("porn");
		/*Blacklist.getInstance().enable_categorie("drugs");*/  
		dns_handler = new DNS_Request_Blacklist_Handler(Blacklist.getInstance().getBlacklist(),privileges);
		
		Logger.log(Levels.PEX_INFO, MODULE_NAME, "Category 'porn' is blocked by default.");
		Logger.log(Levels.PEX_INFO, MODULE_NAME, "DnsFillterMonoliticVersion startup finished.");
		
		return true;
	}
	
	/*
	 * This method is called by the OSGi framework when the application
	 * must be stopped.
	 */
	public void shutDown()
	{
		Logger.log(Levels.PEX_INFO, MODULE_NAME, "DnsFillterMonoliticVersion shutdown.");
		packetDispatcher.RemoveApplication(id);
	}
	
	/*
	 * This is the 'main' method of the application. In fact, it is the method invoked by the 
	 * PEX in order to provide packets to the application. Note that this method receives a 
	 * packet at a time.
	 * 
	 * \param	pkt				The packet which the application can manage
	 *  
	 * \param 	direction		An enumeration value that represent the flux 
	 * 							direction of the packet  
	 *
	 * \param 	input_interface	The input interface of the packet just received		 
	 *
	 * \param 	out_interfaces	An object reference representing the list of 
	 * 							output interfaces for the current packet.
	 *  
	 * \return	CONTINUE if the packet can continue on its way, DROP if the 
	 * 			packet must be dropped
	 */
	@Override
	public Application_exit_status OnReceivedPacket(Packet packet, Direction direction, 
			/*INPUTInterface*/ short inputInterface, OUTInterfaces outputInterface)
	{
//		Msg.show(Msg.DEBUG, MODULE_NAME + "packet received.");
				
		byte[] packetData = packet.getPKT();
		if(DNS.isDnsQuery(packetData))
		{
			String msg = "Received a DNS query";
			Logger.log(Levels.PEX_DEBUG, MODULE_NAME, msg);
			return dns_handler.handle_packet(packetData);
		}    
		return Application_exit_status.CONTINUE;
	}
	
	public void setPacketDispatcher(PacketDispatcher packetDispatcher) 
	{
		this.packetDispatcher = packetDispatcher;
	}	
	
	public String getName()
	{
		return "DnsFilter";
	}	
}
