package dnsFilter;

import org.apache.felix.http.api.ExtHttpService;
import org.osgi.framework.BundleActivator;
import org.osgi.framework.BundleContext;
import org.osgi.framework.ServiceReference;
import org.osgi.util.tracker.ServiceTracker;

import servlets.*;
import util.Logger;
import frog.export.log.Levels;
import frog.export.packetDispatcher.PacketDispatcher;

public class DnsFilterMonoliticVersionActivator implements BundleActivator {

	static public String MODULE_NAME= "DNSFILTER-MONO";

	@SuppressWarnings("rawtypes")
	private ServiceTracker tracker;
	
	DnsFilterMonoliticVersion application;
	private PacketDispatcher packet_dispatcher_service;
	
	/*
	 * The following variables are used to register/unregister servlets in 
	 * the web server
	 */
	DisableCategory disableCategoryServlet = null;
	EnableCategory enableCategoryServlet = null;
	GetCategories getCategoriesServlet = null;
	GetQueries getQueriesServlet = null;
	ExtHttpService ExtHttpServiceHandle = null;
	
	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public void start(BundleContext bundleContext) throws Exception {

		/*
		 * First, the logger must be retrieved. If not, quit the application.
		 */
		ServiceReference<?> logger_ref = bundleContext.getServiceReference(frog.export.log.Logger.class.getName());  
		if (logger_ref == null) 
		{  
			/*
			 * Here the logger cannot be used yet.
			 * TODO
			 * Using of System.out an System.err should be avoided and other way
			 * should be found
			 */
			System.err.println("[ERROR][" + MODULE_NAME+ "] Logger service is not registered...");  
			this.stop(bundleContext);
		}
		
		/*
		 * The logger can be retrieved. So it is set inside the logger wrapper
		 */
		frog.export.log.Logger logger = (frog.export.log.Logger)bundleContext.getService(logger_ref); 
		Logger.setLogger(logger);

		logger.log(Levels.PEX_INFO, MODULE_NAME, "OSGI activator has been called.");

		application = new DnsFilterMonoliticVersion();
		 
		/*
		 * Obtain the services exported by the PEX
		 */
		
		ServiceReference packet_dispatcher_ref = bundleContext.getServiceReference(PacketDispatcher.class.getName());  
  
		if (packet_dispatcher_ref == null) 
		{  
		   logger.log(Levels.PEX_ERROR, MODULE_NAME, "Error: Packet Dispatcher service is not registered...");  
		   this.stop(bundleContext);
		}
		else
		{
			packet_dispatcher_service = (PacketDispatcher)bundleContext.getService(packet_dispatcher_ref); 
			application.setPacketDispatcher(packet_dispatcher_service);      
		}
				
		/*
		 * Start a tracker
		 */
		this.tracker = new ServiceTracker(bundleContext, ExtHttpService.class.getName(), null)
		{
			@Override
			public Object addingService(ServiceReference ref)
			{
				Object service =  super.addingService(ref);
				serviceAdded((ExtHttpService)service);
				return service;
			}

			@Override
			public void removedService(ServiceReference ref, Object service)
			{
				serviceRemoved((ExtHttpService)service);
				super.removedService(ref, service);
			}
		};

		this.tracker.open();
				
		/*
		 * Start up the application
		 */		
		if(!application.startUp())
		{
			/*
			 * An error occurred during the initialization of the application
			 */
			this.stop(bundleContext);
			return;
		}

		logger.log(Levels.PEX_INFO, MODULE_NAME, "OSGI application started.");
	}
	
	private void serviceAdded(ExtHttpService service)
	{
		Logger.log(Levels.PEX_INFO, MODULE_NAME, "Registering the web resources");
		
		disableCategoryServlet = new DisableCategory();
		enableCategoryServlet = new EnableCategory();
		getCategoriesServlet = new GetCategories();
		getQueriesServlet = new GetQueries();
		
		// No idea why, but this line triggers an error in the next line. So, removing it.
		// @SuppressWarnings("unused")

		// Saving a pointer to the ExtHttpService; it will be used at deletion time by the stop() call
		ExtHttpServiceHandle = service;
		
		try
		{
			service.registerServlet("/DnsFilterMonoliticVersion/DisableCategory", disableCategoryServlet, null, null);
			service.registerServlet("/DnsFilterMonoliticVersion/EnableCategory", enableCategoryServlet, null, null);
			service.registerServlet("/DnsFilterMonoliticVersion/GetCategories", getCategoriesServlet, null, null);
			service.registerServlet("/DnsFilterMonoliticVersion/GetQueries", getQueriesServlet, null, null);
			service.registerResources("/DnsFilterMonoliticVersion", "/web", null);			
		}
		catch (Exception e)
		{
			Logger.log(Levels.PEX_ERROR, MODULE_NAME, "Failing to register web resources");
			e.printStackTrace();
		}
	}
	
	private void serviceRemoved(ExtHttpService service)
	{
		Logger.log(Levels.PEX_INFO, MODULE_NAME, "Unregistering the web resources");
		
		service.unregisterServlet(disableCategoryServlet);
		service.unregisterServlet(enableCategoryServlet);
		service.unregisterServlet(getCategoriesServlet);
		service.unregisterServlet(getQueriesServlet);
		service.unregister("/web");
	}


	@Override
	public void stop(BundleContext context) throws Exception {
		serviceRemoved(ExtHttpServiceHandle);
		
		Logger.log(Levels.PEX_INFO, MODULE_NAME, "OSGI de-activator has been called.");
		application.shutDown();
		Logger.log(Levels.PEX_INFO, MODULE_NAME, "Application stopped.");
	}
}
