package annotations;

public @interface FieldExtraction {

	String value();

}
