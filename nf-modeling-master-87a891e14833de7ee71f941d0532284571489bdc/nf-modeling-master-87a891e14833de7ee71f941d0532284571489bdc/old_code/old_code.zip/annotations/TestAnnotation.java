package annotations;

public @interface TestAnnotation {

}
