package annotations;

public @interface Predicate {

	String value();

}
