/**********************************************************************************
*																				  *
* Copyright notice: please read file license.txt in the application root folder.  *
*                                              								      *
**********************************************************************************/

package servlets;

import java.io.IOException;


import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import stats.QueryCache;


import com.google.gson.Gson;

public class GetQueries extends HttpServlet{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
	
		
		Gson json = new Gson();
		resp.setContentType("application/json");
		/*Map<String, QueryInfo> query = QueryCache.getQueriesInfo();
		query.put("youporn.com", new QueryInfo("youporn.com", true));
		resp.getWriter().print(json.toJson(query.values()));
		*/
		resp.getWriter().print(json.toJson(QueryCache.getQueriesInfo().values()));
	}

	
}
