/**********************************************************************************
*																				  *
* Copyright notice: please read file license.txt in the application root folder.  *
*                                              								      *
**********************************************************************************/

package servlets;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.gson.Gson;

import dnsFilter.Blacklist;

import java.util.Map;

public class GetCategories  extends HttpServlet{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
	
		Map<String, Boolean> enabled = Blacklist.getInstance().getCategories();
		
		Gson json = new Gson();
		
		resp.setContentType("application/json");
		resp.getWriter().print(json.toJson(enabled));
		
	}

	
	
}
