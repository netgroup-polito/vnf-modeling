/**********************************************************************************
*																				  *
* Copyright notice: please read file license.txt in the application root folder.  *
*                                              								      *
**********************************************************************************/

package stats;

import java.util.*;


public class QueryInfo {

	
	private boolean blocked;
	private Date data;
	private String query;
	
	public QueryInfo(String query,boolean b) {
		this.blocked = b;
		this.data = new Date();
		this.query = query;
	}
	
	public boolean isBlocked() {
		return blocked;
	}
	public void setBlocked(boolean blocked) {
		this.blocked = blocked;
	}
	public Date getData() {
		return data;
	}
	public void setData(Date data) {
		this.data = data;
	}

	public String getQuery() {
		return query;
	}

	public void setQuery(String query) {
		this.query = query;
	}
	
}
