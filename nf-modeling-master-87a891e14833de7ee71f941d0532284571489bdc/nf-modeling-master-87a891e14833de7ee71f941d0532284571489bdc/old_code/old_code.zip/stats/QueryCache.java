/**********************************************************************************
*																				  *
* Copyright notice: please read file license.txt in the application root folder.  *
*                                              								      *
**********************************************************************************/

package stats;

import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;

import dnsFilter.Cache;


public class QueryCache {

	private static Map<String, QueryInfo> queries = Collections.synchronizedMap(new Cache<String, QueryInfo>(100));
	
	public static void putQuery(String query, QueryInfo info)
	{
		queries.put(query, info);
	}
	
	public static Map<String,QueryInfo> getQueriesInfo()
	{
		// I return a copy
		return new LinkedHashMap<String, QueryInfo>(queries);
		
	}
}
