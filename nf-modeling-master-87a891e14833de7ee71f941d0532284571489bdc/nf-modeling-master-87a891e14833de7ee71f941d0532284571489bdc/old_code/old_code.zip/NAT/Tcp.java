package NAT;

import java.nio.ByteBuffer;
import java.util.Arrays;

import frog.export.log.Logger;
import frog.export.protocols.IPv4;;

public class Tcp {
	
	NAT.IPv4 ip =  new NAT.IPv4();
	NAT.Ethernet eth = new NAT.Ethernet();
	
	short check_sum(byte[] buffer,int ip_header_total_lenght,int ip_header){
	  
		
		int t=0;
	    t = (buffer[Ethernet.ETH_HLEN+ip_header*4+16] )  ;
		t =   t << 8 ;		
	    t +=  ( 0x00ff &  buffer[Ethernet.ETH_HLEN+ip_header*4+16+1]  );
	    
    	return (short)t;
		
	}
	
short check_sum2(byte[] buffer,int ip_header_total_lenght,int ip_header){
	    
		int t=0;
	    t = (buffer[Ethernet.ETH_HLEN+ip_header*4+12] )  ;
		t =   t >> 4 & 0x0f ;		
		
		
		
		
	/*	int t=0;
	    t = (buffer[eth.ETH_HLEN+ip_header*4+16] )  ;
		t =   t << 8 ;		
	    t +=  ( 0x00ff &  buffer[eth.ETH_HLEN+ip_header*4+16+1]  );*/
	    
    	return (short)t;
		
	}
	
	
	
	void set_check(byte[] buffer, short check,int ip_header){
		buffer[Ethernet.ETH_HLEN+ip_header*4+16] =  (byte) ( check >> 8) ;
				buffer[Ethernet.ETH_HLEN+ip_header*4+16+1] = (byte) (check & 0x00ff);
	}
	
	void reset_check(byte[] buffer,int ip_header){
		buffer[Ethernet.ETH_HLEN+ip_header*4+16] =  0 ;
				buffer[Ethernet.ETH_HLEN+ip_header*4+16+1] = 0;
	}
	
	
	  byte[] htonl(int x)
		{
		byte[] res = new byte[4];
		for (int i = 0; i < 4; i++)
		{
		res[i] = (new Integer(x >>> 24)).byteValue();
		x <<= 8;
		}
		return res;
		}

	
	
	public short tcp_checksum(short len,IPv4 ipv4,byte buffer[], int ip_header,Logger logger,String MODULE_NAME){
		
		int nlen = len - ip_header;
		int accumulation = 0;
		byte temp[] = new byte[nlen];
		Arrays.fill(temp, (byte)0);
		System.arraycopy(buffer,14+ip_header*4, temp, 0, nlen);
		
		ByteBuffer bb = ByteBuffer.wrap(temp);
		 
	 
            // compute pseudo header mac
      
               
                accumulation += ((ipv4.getSourceAddress() >> 16) & 0xffff)
                        + (ipv4.getSourceAddress() & 0xffff);
                accumulation += ((ipv4.getDestinationAddress() >> 16) & 0xffff)
                        + (ipv4.getDestinationAddress() & 0xffff);
      /*          int t1 = (int)(ipv4.getProtocol().getValue() & 0xff);
                byte g1[] = htonl(t1);
                t1=0;
                t1=g1[2];
                t1=t1 << 8 ;
                t1 += 0x00ff & g1[3];*/

              accumulation += ipv4.getProtocol().getValue() & 0xff;
          /*      accumulation += t1;
                int t2 = (int)(nlen & 0xffff);
               byte g2[] = htonl(t2);
                t2=0;
                t2=g2[2];
                t2= t2 << 8 ;
                t2 += 0x00ff & g2[3];
*/

               // accumulation += t2;
                 accumulation += nlen & 0xffff;
           

            for (int i = 0; i < nlen / 2; ++i) {
                accumulation += 0xffff & bb.getShort();
            }
            // pad to an even number of shorts
            if (nlen % 2 > 0) {
            
                accumulation += (bb.get() & 0xff) << 8;
            }

            accumulation = (accumulation >> 16)   + (accumulation & 0xffff);
              accumulation += (accumulation >> 16);
            return  (short) (~accumulation);
            
			
		}

}
