package NAT;

import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

public class Connession_descriptor {
	
	private int IPs;
	private int IPd;
	private short Ps_mapped;
	private short Ps;
	private short Pd;
	private String protoType;
	private int icmp_id;
	private Long time;
 
	protected static List<Integer> assigned_port;
	
	Connession_descriptor(int dest_ip , int source_ip,short  source_port, short dest_port, String pt){
		IPd = dest_ip;
		IPs=source_ip;
		Ps=source_port;
		Pd=dest_port;
		protoType = pt;
		Ps_mapped =0;
	 
		
		if(assigned_port == null){
			
			assigned_port= new CopyOnWriteArrayList<Integer>();
		}
		
	}
	
	Connession_descriptor(int dest_ip , int source_ip, int id,String pt){
		IPd = dest_ip;
		IPs=source_ip;
	    icmp_id=id;
	    protoType = pt;
 	    Ps_mapped =0;
 	     
 	   
       if(assigned_port == null){
			
			assigned_port= new CopyOnWriteArrayList<Integer>();
		}
	}
	
    
	
	void set_time(Long b){ time = b;}
   	
	void set_IPs(int i){ IPs = i; }
	
	void set_Ps_mapped(short i){ Ps_mapped = i; }
	
	void set_ICMP_ID(int i){ icmp_id = i; }
	
	void set_IPd(int i){ IPd = i; }
	
	void set_Ps(short ps){ Ps = ps ;}
		
	void set_Pd(short pd){ Pd = pd ;}
	 
	void set_protoType(String pt){ protoType = pt ;}
	
	Long get_time(){return time;}
	
    int get_IPs(){ return IPs;}
    
    short get_Ps_mapped(){ return Ps_mapped;}
    
    int get_ICMP_ID(){ return icmp_id;}
    
    int get_IPd(){ return IPd;}
    
    short get_Ps(){ return Ps;}
    
    short get_Pd(){ return Pd;}
    
    String get_protoType(){ return protoType;}
    
    
   short assigned_other_port(){
    	
    	int port = 0;
    	 
    	
    	for(Integer i : assigned_port){
    		 
    		if(i>port) port=i;
    	 
    	}
    	
     
    	
    	if (port == 0) {
    		
    		port=61000;
    		assigned_port.add(port);
    		
    	} else {
    		
    		     
    		      for(int i = 61000; i<=port+1 ; i++){ 
    		    	  
    		      
    		    	if(assigned_port.contains(i) == false && port < 65535)
    		    	{
    		            
    		          assigned_port.add(i);
    		          port = i;
    		          break;
    		        } 
    		    	
    		      }
    		      
    		      //all port full
    		      if(port == 65535) return 0;
    		    
    	       }
    		    
    	
    	Ps_mapped = (short)port;
    	
    	return Ps_mapped;
    	
    }
		
	
}
