package NAT;

import java.util.Arrays;

public class IPv4 {
	
	public static final int IP_HLEN = 20;
	public static final int IP_LEN = 4;
	public static final int TOT_LEN_POS = 2;
	public static final int TTL_POS = 8;
	public static final int PROTOCOL_POS = 9;
	public static final int IP_CHECKSUM_POS = 10;
	public static final int SRC_IP_POS = 12;
	public static final int DST_IP_POS = 16;
	public static final int PROTOCOL_TCP = 0x06;
	public static final int PROTOCOL_UDP = 0x11;

    public static int toIpAddr(String ipAddress)
	{
        if (ipAddress == null)
            throw new IllegalArgumentException("Specified IPv4 address must" +
                "contain 4 sets of numerical digits separated by periods");
        String[] octets = ipAddress.split("\\.");
        if (octets.length != 4) 
            throw new IllegalArgumentException("Specified IPv4 address must" +
                "contain 4 sets of numerical digits separated by periods");

        int result = 0;
        for (int i = 0; i < 4; ++i)
        {
            result |= Integer.valueOf(octets[i]) << ((3-i)*8);
        }
        return result;
    }
	
	public static int toIpAddr(byte[] ipAddress)
	{
        int ip = 0;
        for (int i = 0; i < 4; i++)
        {
        	int t = (ipAddress[i] & 0xff) << ((3-i)*8);
        	ip |= t;
        }
        return ip;
    }
	
	public static byte[] toIpAddrBytes(String ipAddress)
	{
        String[] octets = ipAddress.split("\\.");
        if (octets.length != 4) 
            throw new IllegalArgumentException("Specified IPv4 address must" +
                "contain 4 sets of numerical digits separated by periods");

        byte[] result = new byte[4];
        for (int i = 0; i < 4; ++i) {
            result[i] = Integer.valueOf(octets[i]).byteValue();
        }
        return result;
    }

    public static byte[] toIpAddrBytes(int ipAddress)
    {
    	return new byte[] {
                (byte)(ipAddress >>> 24),
                (byte)(ipAddress >>> 16),
                (byte)(ipAddress >>> 8),
                (byte)ipAddress};
    }
    
    public static String toString(int ipAddress)
    {
    	return String.format("%hhu.%hhu.%hhu.%hhu",
    			(ipAddress >> 24) & 0xff,
    			(ipAddress >> 16) & 0xff,
    			(ipAddress >> 8) & 0xff,
    			ipAddress & 0xff
    			);
    }
    
    public static short getTotalLength(byte[] packet)
    {
    	return (short)(((packet[Ethernet.ETH_HLEN+TOT_LEN_POS] << 8) & 0xff00) |
    			(packet[Ethernet.ETH_HLEN+TOT_LEN_POS+1] & 0xff));
    }
    
    public static byte getProtocol(byte[] packet)
    {
    	return packet[Ethernet.ETH_HLEN+PROTOCOL_POS];
    }
    
    public static void resetChecksum(byte[] packet)
    {
    	packet[Ethernet.ETH_HLEN+IP_CHECKSUM_POS] = (byte)0;
    	packet[Ethernet.ETH_HLEN+IP_CHECKSUM_POS+1] = (byte)0;
//    	packetDissectors.IPv4 ip = new packetDissectors.IPv4();
//    	ip.deserialize(packet, Ethernet.ETH_HLEN, IP_HLEN+getTotalLength(packet));
//    	ip.resetChecksum();
//    	short cksum = ip.getChecksum();
    	
    	short cksum = ip_cksum(packet);
    	
    	packet[Ethernet.ETH_HLEN+IP_CHECKSUM_POS] = (byte)((cksum >> 8) & 0xff);
    	packet[Ethernet.ETH_HLEN+IP_CHECKSUM_POS+1] = (byte)(cksum & 0xff);
    }
    
    private static short ip_cksum(byte[] packet)
    {
        int nleft = IP_HLEN;
        int cursor = Ethernet.ETH_HLEN;
        int sum = 0;
        short res = 0;

        /*
         * Our algorithm is simple, using a 32 bit accumulator (sum), we add
         * sequential 16 bit words to it, and at the end, fold back all the
         * carry bits from the top 16 bits into the lower 16 bits.
        */
        
        while (nleft > 1)
        {
            sum += ((packet[cursor] << 8) & 0xff00) + (packet[cursor+1] & 0xff);
            nleft -= 2;
            cursor += 2;
        }

        /* mop up an odd byte, if necessary */
        if (nleft == 1)
        {
        	sum += ((packet[cursor] << 8) & 0xff00);
        }

        /* add back carry outs from top 16 bits to low 16 bits */
        while((sum & 0xffff0000) != 0)
        {
        	sum = (sum & 0xffff) + ((sum >> 16) & 0xffff);
//            sum += (sum >> 16);
        }
        /* guaranteed now that the lower 16 bits of sum are correct */

        res = (short)((~sum) & 0xffff);              /* truncate to 16 bits */
        return res;
    }

    
    public static byte getTTL(byte[] packet)
    {
    	return packet[Ethernet.ETH_HLEN+TTL_POS];
    }
    
    public static void setTTL(byte[] packet, byte ttl)
    {
    	packet[Ethernet.ETH_HLEN+TTL_POS] = ttl;
    }
    
    public static void setSrcIp(byte[] packet, int ip)
    {
        System.arraycopy(IPv4.toIpAddrBytes(ip), 0, packet, Ethernet.ETH_HLEN+SRC_IP_POS, IP_LEN);
    }
    
	public static void setDstIp(byte[] packet, int ip)
    {
        System.arraycopy(IPv4.toIpAddrBytes(ip), 0, packet, Ethernet.ETH_HLEN+DST_IP_POS, IP_LEN);
    }
    
	public static int getSrcIp(byte[] packet)
    {
        return toIpAddr(Arrays.copyOfRange(packet, Ethernet.ETH_HLEN+SRC_IP_POS, Ethernet.ETH_HLEN+SRC_IP_POS+IP_LEN));
    }
    
	public static int getDstIp(byte[] packet)
    {
        return toIpAddr(Arrays.copyOfRange(packet, Ethernet.ETH_HLEN+DST_IP_POS, Ethernet.ETH_HLEN+DST_IP_POS+IP_LEN));
    }
    
	public static short getIpChecksum(byte[] packet)
    {
    	return (short)(((packet[Ethernet.ETH_HLEN+IP_CHECKSUM_POS] << 8) & 0xff00) |
    			(packet[Ethernet.ETH_HLEN+IP_CHECKSUM_POS+1] & 0xff));
    }
    
	public static void setIpChecksum(byte[] packet, short checksum)
    {
    	packet[Ethernet.ETH_HLEN+IP_CHECKSUM_POS] = (byte)((checksum >> 8) & 0xff);
    	packet[Ethernet.ETH_HLEN+IP_CHECKSUM_POS+1] = (byte)(checksum & 0xff);
    }

}
