package NAT;

import java.util.Arrays;

public class Ethernet {

    
	public final static int ETH_HLEN = 14;
	public final static int DST_MAC_POS = 0;
	public final static int SRC_MAC_POS = 6;
	public final static int MAC_LEN = 6;
	public final static int ETH_TYPE_POS = 12;
	public final static int TYPE_IPv4 = 0x0800;
	public final static short TYPE_ARP = 0x0806;
	
	public static byte[] getDstMac(byte[] packet)
	{
		return Arrays.copyOfRange(packet, DST_MAC_POS, DST_MAC_POS+MAC_LEN);
	}
	
	public static byte[] getSrcMac(byte[] packet)
	{
		return Arrays.copyOfRange(packet, SRC_MAC_POS, SRC_MAC_POS+MAC_LEN);
	}
    
	public static void setDstMac(byte[] packet, byte[] dst)
    {
        System.arraycopy(dst, 0, packet, DST_MAC_POS, MAC_LEN);
    }
    
	public static void setSrcMac(byte[] packet, byte[] src)
    {
        System.arraycopy(src, 0, packet, SRC_MAC_POS, MAC_LEN);
    }
    
	public static short getEtherType(byte[] packet)
    {
        return (short)(((packet[ETH_TYPE_POS] << 8) & 0xff00) | (packet[ETH_TYPE_POS+1] & 0xff));
    }
    
}
