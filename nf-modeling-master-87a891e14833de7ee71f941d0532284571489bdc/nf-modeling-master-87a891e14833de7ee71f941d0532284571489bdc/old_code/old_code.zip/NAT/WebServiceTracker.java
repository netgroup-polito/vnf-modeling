/************************************************************************************
 *																					*
 *     Copyright notice: please read file license.txt in the project root folder.   *
 *                                              								    *
 ************************************************************************************/

/**
 * \file WebServiceTracker.java
 *
 * \author Ivano Cerrato
 *
 * 
 * This class is needed ONLY if the application exports servlets or other web resources.
 * In fact, as soon as the HTTP service is exported by the PEX, it register the servlets 
 * and other web resources so that they are accessible through HTTP. It is also able to 
 * register web filters
 */

package NAT;

import org.apache.felix.http.api.ExtHttpService;
import org.osgi.framework.BundleContext;
import org.osgi.framework.ServiceReference;
import org.osgi.util.tracker.ServiceTracker;
import org.osgi.util.tracker.ServiceTrackerCustomizer;

import frog.export.log.Levels;
import frog.export.log.Logger;
import Servlet.Filter;
import Servlet.NATServlet;


@SuppressWarnings("rawtypes")
public class WebServiceTracker extends ServiceTracker{

	private NATServlet servlet = null;
	private Filter filter = null;
	
	private Logger logger;
	private final String MODULE_NAME = NATActivator.MODULE_NAME;
	private NATActivator natActivator;
	

	@SuppressWarnings({ "unchecked" })
	public WebServiceTracker(BundleContext context, String string,
			ServiceTrackerCustomizer customizer, Logger logger, NATActivator natActivator) 
	{
		super(context, string, customizer);
		this.logger = logger;
		this.natActivator = natActivator;
		
		servlet = new NATServlet(logger);
		filter = new Filter(logger);
	}
	
	@Override
	@SuppressWarnings("unchecked")
	public Object addingService(ServiceReference ref)
	{
		Object service =  super.addingService(ref);
		serviceAdded((ExtHttpService)service);
		return service;
	}

	@Override
	@SuppressWarnings("unchecked")
	public void removedService(ServiceReference ref, Object service)
	{
		serviceRemoved((ExtHttpService)service);
		super.removedService(ref, service);
	}
	
	/**
	 * This function is invoked by the framework when the HTTP service is exported.
	 * It is used to register the servlets, filters and the web resources of the application
	 */
	private void serviceAdded(ExtHttpService service)
	{
		logger.log(Levels.PEX_INFO, MODULE_NAME, "Registering the web resources");
		
		try
		{
			/*
			 * Register the servlet
			 */
			
	 
			service.registerServlet("/NAT/servlet", servlet, null, null);
			 
	  
			/*
			 * Register the filter
			 */
			service.registerFilter(filter, "/", null, 0, null);
			
	 
			/*
			 * Register other web resources
			 */
			service.registerResources("/NAT", "/web",null);
						
			logger.log(Levels.PEX_INFO, MODULE_NAME, "All the web resources have been initialized!");
		}
		catch (Exception e)
		{
			logger.log(Levels.PEX_ERROR, MODULE_NAME, "Failing to register web resources. The application will be stopped.");
			logger.log(Levels.PEX_ERROR, MODULE_NAME, e.getMessage());
			e.printStackTrace();
			try {
				natActivator.stop(null);
			} catch (Exception e1) {
				logger.log(Levels.PEX_ERROR, MODULE_NAME, "An exception occurred while stopping the application");
				logger.log(Levels.PEX_ERROR, MODULE_NAME, e.getMessage());
				e1.printStackTrace();
			}
		}
	}
	
	/**
	 * This function is invoked by the framework when the HTTP service is no longer exported.
	 * It is used to unregister the servlets, filters and the web resources of the application.
	 */
	private void serviceRemoved(ExtHttpService service)
	{
		logger.log(Levels.PEX_INFO, MODULE_NAME, "The HTTP service has been unregistered by the PEX");
		logger.log(Levels.PEX_INFO, MODULE_NAME, "Unregistering the web resources");
		
		/*
		 * Unregister the servlet
		 */
		service.unregisterServlet(servlet);
		
		/*
		 * Unregister the filter
		 */
		service.unregisterFilter(filter);
		
		/*
		 * Unregister other web resources
		 */
		service.unregister("/web");
		
		logger.log(Levels.PEX_INFO, MODULE_NAME, "The application is going to be stopped, since it needs the HTTP service");
		
		try {
			natActivator.stop(null);
		} catch (Exception e) {
			logger.log(Levels.PEX_ERROR, MODULE_NAME, "An exception occurred while stopping the application");
			logger.log(Levels.PEX_ERROR, MODULE_NAME, e.getMessage());
		}
	}
}

