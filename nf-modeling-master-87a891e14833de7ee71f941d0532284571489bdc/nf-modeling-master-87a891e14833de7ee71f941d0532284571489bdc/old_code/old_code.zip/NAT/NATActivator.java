/************************************************************************************
*																					*
*     Copyright notice: please read file license.txt in the project root folder.    *
*                                              								        *
************************************************************************************/

/**
 * \file NATActivator.java
 *
 *
 */

package NAT;

import org.apache.felix.http.api.ExtHttpService;
import org.osgi.framework.BundleActivator;
import org.osgi.framework.BundleContext;
import org.osgi.framework.ServiceReference;
import org.osgi.util.tracker.ServiceTracker;

import frog.export.appConf.AppConf;
import frog.export.interfaceManager.InterfaceManager;
import frog.export.log.Levels;
import frog.export.log.Logger;
import frog.export.packetDispatcher.PacketDispatcher;

public class NATActivator implements BundleActivator {

	NATApplication application;
	private PacketDispatcher packet_dispatcher_service;
	private InterfaceManager interface_manager_service;
	public static final String MODULE_NAME = "NAT";
	private Logger logger;
	
	/*
	 * Currently the RESTO is not supported
	 */
	//private Storage storage_service;
	
	/*
	 * The following variables are used to register/unregister servlets and
	 * other web resources
	 */
	@SuppressWarnings("rawtypes")
	private ServiceTracker tracker;
	
	@Override
	/**
	 * This function is called by the framework in order to startup the application
	 */
	public void start(BundleContext bundleContext) throws Exception 
	{	
		ServiceReference<?> logger_ref = bundleContext.getServiceReference(Logger.class.getName());
		if(logger_ref == null)
		{
			/*
			 * Here the logger cannot be used, since the error is due to
			 * the logger itself
			 */
			 System.out.println("[NAT] Logger service is not registered...");  
			 this.stop(bundleContext);
		}
		else
		{
			logger = (Logger)bundleContext.getService(logger_ref); 
		}
		
		logger.log(Levels.PEX_INFO, MODULE_NAME, "OSGI activator has been called." + Logger.class.getName());

		application = new NATApplication();
		
		application.setLogger(logger);
		 
		ServiceReference<?> packet_dispatcher_ref = bundleContext.getServiceReference(PacketDispatcher.class.getName());    
		if (packet_dispatcher_ref == null) 
		{  
		   logger.log(Levels.PEX_ERROR, MODULE_NAME, "error: Packet Dispatcher service is not registered...");  
		   this.stop(bundleContext);
		}
		else
		{
			packet_dispatcher_service = (PacketDispatcher)bundleContext.getService(packet_dispatcher_ref); 
			application.setPacketDispatcher(packet_dispatcher_service);      
		}
		
		ServiceReference<?> interface_manager_ref = bundleContext.getServiceReference(InterfaceManager.class.getName());  		
		if (interface_manager_ref == null) 
		{  
		   logger.log(Levels.PEX_ERROR, MODULE_NAME, "error: InterfaceManager service is not registered...");  
		   this.stop(bundleContext);
		}
		else
		{
			interface_manager_service = (InterfaceManager)bundleContext.getService(interface_manager_ref); 
			application.setInterfaceManager(interface_manager_service);      
		}
		
		
		ServiceReference<?> app_conf_ref = bundleContext.getServiceReference(AppConf.class.getName());  
	    
		 if (app_conf_ref == null) 
		    {  
				logger.log(Levels.PEX_ERROR, MODULE_NAME, "AppConf service is not registered...");  
				this.stop(bundleContext);
		    }
		    else
		    { 	    	
		        AppConf app_conf_service = (AppConf)bundleContext.getService(app_conf_ref); 
		        String configPath = app_conf_service.getConfFilePath(bundleContext.getBundle().getSymbolicName() + "-config");
				logger.log(Levels.PEX_INFO, MODULE_NAME, "Asking for config file named '" + bundleContext.getBundle().getSymbolicName() + "-config" + "'");  
				logger.log(Levels.PEX_INFO, MODULE_NAME, "The requested config file is at '" + configPath + "'");  

		        String schemaPath = app_conf_service.getConfFilePath(bundleContext.getBundle().getSymbolicName() + "-schema");

				logger.log(Levels.PEX_INFO, MODULE_NAME, "Asking for schema file named '" + bundleContext.getBundle().getSymbolicName() + "-schema" + "'");  
				logger.log(Levels.PEX_INFO, MODULE_NAME, "The requested schema file is at '" + schemaPath + "'");  
				
				String urlCentralServlet = app_conf_service.getConfFilePath(bundleContext.getBundle().getSymbolicName() + "-urlCentral_Servlet");

			    logger.log(Levels.PEX_INFO, MODULE_NAME, "Asking for schema file named '" + bundleContext.getBundle().getSymbolicName() + "-urlCentral_Servlet" + "'");  
			    logger.log(Levels.PEX_INFO, MODULE_NAME, "The urlCentral_Servlet is '" + urlCentralServlet + "'");  
			    
			    String clear_time = app_conf_service.getConfFilePath(bundleContext.getBundle().getSymbolicName() + "-clear_time");

			    logger.log(Levels.PEX_INFO, MODULE_NAME, "Asking for schema file named '" + bundleContext.getBundle().getSymbolicName() + "-clear_time" + "'");  
			    logger.log(Levels.PEX_INFO, MODULE_NAME, "The clear time is '" + clear_time + "'"); 
			    
		        application.setPath(configPath, schemaPath,urlCentralServlet,clear_time);     
		    }
		
		/*
		 * Currently the RESTO is not supported
		 */
		/*ServiceReference<?> storage_ref = bundleContext.getServiceReference(Storage.class.getName());  
		
		if (storage_ref == null) 
		{  
		   System.out.println("NAT error: Storage service is not registered...");  
		   this.stop(bundleContext);
		}
		else
		{
			storage_service = (Storage)bundleContext.getService(storage_ref); 
			application.setStorage(storage_service);      
		}
		*/
		
		/*
		 * Start a tracker to register/unregister the web resources
		 */
		tracker = new WebServiceTracker(bundleContext, ExtHttpService.class.getName(), null, logger, this);
		tracker.open();
		
		if(!application.startUp(bundleContext))
		{
			logger.log(Levels.PEX_ERROR, MODULE_NAME, "Error at the start up!");
			this.stop(bundleContext);
		}
			
		logger.log(Levels.PEX_INFO, MODULE_NAME, "OSGI activator terminated.");
	}

	@Override
	/**
	 * This function is invoked by the framework in order to shut down the application
	 */
	public void stop(BundleContext context) throws Exception {
		logger.log(Levels.PEX_INFO, MODULE_NAME, "OSGI de-activator has been called.");
		application.shutDown();
	}
	
	

}
