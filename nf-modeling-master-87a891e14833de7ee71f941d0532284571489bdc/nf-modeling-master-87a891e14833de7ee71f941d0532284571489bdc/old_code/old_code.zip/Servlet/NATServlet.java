/************************************************************************************
*																					*
*     Copyright notice: please read file license.txt in the project root folder.    *
*                                              								        *
************************************************************************************/

/**
 * \file HelloWorldServlet.java
 *
 * \author Ivano Cerrato
 *
 */

package Servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import NAT.NATActivator;
import NAT.NATApplication;
import frog.export.log.Levels;
import frog.export.log.Logger;
import frog.export.protocols.IPv4;

public class NATServlet extends HttpServlet{	

	private Logger logger;
	private final String MODULE_NAME = NATActivator.MODULE_NAME;
	 private final static String _NAME = "ip";
	 
	 
	private static final long serialVersionUID = 1L;

	public NATServlet(Logger logger) {
		this.logger = logger;
	}

	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		response.getWriter().println("Hello,this is the NAT servlet");
	}
	
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse response)
			throws ServletException, IOException {
		
	  
		  
	     String s = req.getParameter( _NAME );
	
	     if(s != null){
	    
	        logger.log(Levels.PEX_INFO, MODULE_NAME, "nuovo ip " + s);
	        response.getWriter().println("ip " + s + " received");
	     
	    	synchronized(NATApplication.NatTable) {	     
	    		NATApplication.WAN_IP = IPv4.toIPv4Address(s);
	    		//nat.NatTable.clear();
	       
	       }  
	    
	     
	     
		  }
	      
		 
	   	
		  
		
	     
	        
	       
	        
	        
	}

	@Override
	public void init() throws ServletException {	
		super.init();		
		 
	}

}

