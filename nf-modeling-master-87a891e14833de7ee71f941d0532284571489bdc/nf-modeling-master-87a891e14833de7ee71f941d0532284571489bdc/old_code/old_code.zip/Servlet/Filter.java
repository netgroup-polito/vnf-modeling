/************************************************************************************
*																					*
*     Copyright notice: please read file license.txt in the project root folder.    *
*                                              								        *
************************************************************************************/

/**
 * \file Filter.java
 *
 * \author Ivano Cerrato
 *
 */

package Servlet;

import java.io.IOException;

import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;

import NAT.NATActivator;

import frog.export.log.Levels;
import frog.export.log.Logger;

public class Filter implements javax.servlet.Filter {
	
	private final String MODULE_NAME = NATActivator.MODULE_NAME;
	private Logger logger;

	public Filter(Logger logger) {
		this.logger = logger;
	}

	@Override
	public void destroy() {

	}

	@Override
	public void doFilter(ServletRequest request, ServletResponse response,
			FilterChain chain) throws IOException, ServletException 
	{
			logger.log(Levels.PEX_INFO, MODULE_NAME, "do filter");
			chain.doFilter(request, response);
			logger.log(Levels.PEX_INFO, MODULE_NAME, "do filter2");
	}

	@Override
	public void init(FilterConfig arg0) throws ServletException {
		logger.log(Levels.PEX_INFO, MODULE_NAME, "The filter has been initialized.");
	}


}
